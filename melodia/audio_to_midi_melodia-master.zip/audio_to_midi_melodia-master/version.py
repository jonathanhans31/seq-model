#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Version info"""

short_version = '0.0'
version = '0.0.2'
